import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

import { Auction } from '../auction';
import { AuctionService } from '../auction.service';

@Component({
  selector: 'app-auction-list',
  templateUrl: './auction-list.component.html',
  styleUrls: ['./auction-list.component.css']
})
export class AuctionListComponent implements OnInit {

  auctions : Auction[] =[];

  constructor(private auctionService: AuctionService , private router:Router){

  }

  ngOnInit(): void {
    this.getAuctiondetails();
  }
  private getAuctiondetails(){
    this.auctionService.getAuctionList().subscribe(data => {
      this.auctions=data;
    });
  }
  updateDetails(id: number)
{
  this.router.navigate(['update-details',id])
}

deleteDetails(id: number)
{
this.auctionService.deleteDetails(id).subscribe(data =>{
  console.log(data);
  this.getAuctiondetails();
})
}

auctionDetails(id: number)
{
  this.router.navigate(['auction-details',id])
}
}
