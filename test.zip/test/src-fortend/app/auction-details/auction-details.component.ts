import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Auction } from '../auction';
import { AuctionService } from '../auction.service';

@Component({
  selector: 'app-auction-details',
  templateUrl: './auction-details.component.html',
  styleUrls: ['./auction-details.component.css']
})
export class AuctionDetailsComponent implements OnInit {
  ngOnInit(): void {
    throw new Error('Method not implemented.');
  }
  auction: Auction = new Auction();
  id: number = 0;
  
  constructor(private auctionService: AuctionService , private router:Router,private route: ActivatedRoute){
    this.id=this.route.snapshot.params['id'];
    this.auctionService.getDetailsById(this.id).subscribe(data =>{this.auction=data;},error => console.log(error));
  }

}
