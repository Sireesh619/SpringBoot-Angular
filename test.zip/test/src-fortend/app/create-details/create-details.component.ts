import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Auction } from '../auction';
import { AuctionService } from '../auction.service';

@Component({
  selector: 'app-create-details',
  templateUrl: './create-details.component.html',
  styleUrls: ['./create-details.component.css']
})
export class CreateDetailsComponent implements OnInit  {

  auction : Auction=new Auction();
  constructor(private auctionService: AuctionService , private router:Router){

  }

  ngOnInit(): void {
    throw new Error('Method not implemented.');
  }

  saveEmployee()
  {
   this.auctionService.createDetails(this.auction).subscribe(data =>{
   console.log(data)
   this.goToAuctionList();
   },
   error => console.log(error));
  }

  goToAuctionList()
  {
   this.router.navigate(['/auction-list']);
  }

 onSubmit(){
   console.log(this.auction);
   this.saveEmployee();
 }

}
