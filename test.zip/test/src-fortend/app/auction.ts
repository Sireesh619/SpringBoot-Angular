export class Auction {
    id : number = 0;
    itemname :string = "";
    buyer :string = "";
    amount : string = "";
}
