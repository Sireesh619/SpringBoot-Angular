import { Auction } from './auction';

describe('Auction', () => {
  it('should create an instance', () => {
    expect(new Auction()).toBeTruthy();
  });
});
