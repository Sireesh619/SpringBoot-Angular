import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AuctionDetailsComponent } from './auction-details/auction-details.component';
import { AuctionListComponent } from './auction-list/auction-list.component';
import { UpdateDetailsComponent } from './update-details/update-details.component';
import { CreateDetailsComponent } from './create-details/create-details.component';

const routes: Routes = [
  {path:'auction-list',component: AuctionListComponent},
  {path: 'create-details',component: CreateDetailsComponent},
  {path: 'update-details/:id',component: UpdateDetailsComponent},
  {path: 'auction-details/:id' , component: AuctionDetailsComponent},
  {path:'',redirectTo:'auction-list' ,pathMatch :'full'}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
