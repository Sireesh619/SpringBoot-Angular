import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';

import { Auction } from '../auction';
import { AuctionService } from '../auction.service';

@Component({
  selector: 'app-update-details',
  templateUrl: './update-details.component.html',
  styleUrls: ['./update-details.component.css']
})
export class UpdateDetailsComponent implements OnInit  {
  auction : Auction=new Auction();
  id: number = 0;
  constructor(private auctionService: AuctionService , private router:Router,private route: ActivatedRoute){

  }

  ngOnInit(): void {
    this.id=this.route.snapshot.params['id'];
    this.auctionService.getDetailsById(this.id).subscribe(data =>{this.auction=data;},error => console.log(error));
  }

  onSubmit(){
    this.auctionService.updateDetails(this.id,this.auction).subscribe( data => {
      this.goToAuctionList();
    });
  }
  goToAuctionList()
  {
   this.router.navigate(['/auction-list']);
  }
  
}
