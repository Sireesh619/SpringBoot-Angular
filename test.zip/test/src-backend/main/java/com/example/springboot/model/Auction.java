package com.example.springboot.model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "auction")
public class Auction {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)	
    private long id;
	@Column(name = "item_name")
	private String itemname;
	@Column(name = "buyer_name")
	private String buyer;
	@Column(name = "amount")
	private String amount;
public Auction()
{
	
}

public Auction(String itemname, String buyer, String amount) {
	super();
	this.itemname = itemname;
	this.buyer = buyer;
	this.amount = amount;
}
public long getId() {
	return id;
}
public void setId(long id) {
	this.id = id;
}
public String getItemname() {
	return itemname;
}
public void setItemname(String itemname) {
	this.itemname = itemname;
}
public String getBuyer() {
	return buyer;
}
public void setBuyer(String buyer) {
	this.buyer = buyer;
}
public String getAmount() {
	return amount;
}
public void setAmount(String amount) {
	this.amount = amount;
}


}
