package com.example.springboot.contoller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.springboot.exception.ResourceNotFoundException;
import com.example.springboot.model.Auction;
import com.example.springboot.repository.AuctionRepository;

@RestController
@RequestMapping("/api/v1")
@CrossOrigin("*")
public class AuctionController {
	
	@Autowired
	private AuctionRepository auctionrepository;
	
	@GetMapping("/auction")
	public List<Auction> getdetails()
	{
		return auctionrepository.findAll();
	}
    
	@PostMapping("/auction")
	public Auction savedetails(Auction auction)
	{
		return auctionrepository.save(auction);
	}
	
	@GetMapping("/auction/{id}")
	public ResponseEntity<Auction>  getdetailsById(@PathVariable Long id)
	{
		Auction auction = auctionrepository.findById(id).orElseThrow(() -> new ResourceNotFoundException("details not exsit"));
		return ResponseEntity.ok(auction);
	}
	
	@PutMapping("/auction/{id}")
	public ResponseEntity<Auction>  updatedetailsById(@PathVariable Long id , @RequestBody Auction auctiondeatils)
	{   
		Auction auction = auctionrepository.findById(id).orElseThrow(() -> new ResourceNotFoundException("details not exsit"));
        
		auction.setItemname(auctiondeatils.getItemname());
        auction.setBuyer(auctiondeatils.getBuyer());
        auction.setAmount(auctiondeatils.getAmount());
        Auction updatedetailsById=auctionrepository.save(auction);
		return ResponseEntity.ok(updatedetailsById);
	}
	
	@DeleteMapping("/auction/{id}")
	public ResponseEntity<Map<String, Boolean>> deleteDetails(@PathVariable long id)
	{
		Auction auction = auctionrepository.findById(id).orElseThrow(() -> new ResourceNotFoundException("details not exsit"));
	    auctionrepository.delete(auction);
	    Map<String, Boolean> response = new HashMap<>();
		response.put("deleted", Boolean.TRUE);
		return ResponseEntity.ok(response);	
	}
	
}
